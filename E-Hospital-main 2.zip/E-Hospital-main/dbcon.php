<?php 

	$con = mysqli_connect('localhost:3308','root','','ehospital');
	
	if($con == false)
	{
		echo "Not connected !";
	}
	
?>
	
