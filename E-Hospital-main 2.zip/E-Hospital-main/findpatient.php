<html>
<head>
<title>Hospital Management System</title>
<style>
.f1
{
	margin-top : 40px;
	margin-left : 30px;
}

</style>
</head>
<body>
<div class = "f1">
<form method = "post" action = "index.php" >
<table>
<tr>
<td><input type = "text" name = "name" placeholder = "Enter Patient Name Here..." required /></td>
<td><input type = "number" name = "ward_no" placeholder = "Ward No." required /></td>
<td><input type = "submit" name = "submit" value = "Get Info" /></td>
</tr>
</table>
</form>
</div>
</body>
</html>

