<html>
<head>
<title>Hospital Management System</title>

<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
<link type = "text/css" rel = "stylesheet" href = "../css/index.css" />

</head>
<body style = " background-color :  #29506a; " >
<div class = "login" align = "center" >
	<h1 style = " font-size : 40px;" >TY HOSPITAL</h1>
</div>
<h3 style = "margin-left : 10px;" >Click <a class = "fpass" href = "../login.php">here</a> for admin login or go to <a class = "fpass" href = "../index.php" >Hompage</a> !</h3>
</body>
</html>
