
<div class = "admintitle" align = "center" >
<h1 style = "font-size : 35px;" >Welcome to Admin Dashboard</h1>
</div>
<h3 style = "margin-top : -134px; margin-left : 40px; color : #C70039 ;" align = "left">
<?php
	echo $_SESSION['name']." ".$_SESSION['lname']." :)";
?>
</h3>

<h3 style = "margin-top : 75px; margin-right : 40px; " align = "right"><a class = "alink" title = "Clik here for logout !" href = "logout.php">Logout</a></h3>

<h3 style = "margin-top : -42px; margin-right : 130px; " align = "right"><a class = "alink" title = "Clik here for Homepage !" href = "../index.php">Home</a></h3>


