<html>
<head>
<title>Hospital Management System</title>
<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
<link type = "text/css" rel = "stylesheet" href = "../css/index.css" />
</head>
<body>
