# E-Hospital
Hospital Management System using HTML CSS and PHP
![Screenshot 2022-06-24 203418](https://user-images.githubusercontent.com/73438667/175571200-ab5016f1-80b2-4b4a-8743-374630a102f6.png)
![Screenshot 2022-06-24 203433](https://user-images.githubusercontent.com/73438667/175571206-1f9e61b1-4ee7-422a-82ca-2a3d5cdf416d.png)
![Screenshot 2022-06-24 203454](https://user-images.githubusercontent.com/73438667/175571212-8052f9ff-00e8-4611-b22a-c664c7c573d6.png)
![Screenshot 2022-06-24 203506](https://user-images.githubusercontent.com/73438667/175571213-ffbdc118-282b-40cb-9e52-2d524d01c45d.png)
